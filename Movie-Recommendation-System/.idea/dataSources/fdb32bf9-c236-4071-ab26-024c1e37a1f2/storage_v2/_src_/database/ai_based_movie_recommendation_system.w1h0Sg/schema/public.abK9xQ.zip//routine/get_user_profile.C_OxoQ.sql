create function get_user_profile(id_of_user integer)
    returns TABLE(full_name character varying, date_of_birth date, email character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT d.full_name, d.date_of_birth, d.email
    FROM users u
    JOIN user_details d ON u.user_id = d.user_id
    WHERE u.user_id = id_of_user;
END;
$$;

alter function get_user_profile(integer) owner to postgres;

