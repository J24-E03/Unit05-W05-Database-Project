create view user_query_history(username, title, query, timestamp) as
SELECT u.username,
       m.title,
       q.query,
       q."timestamp"
FROM users u
         JOIN queries q ON u.user_id = q.user_id
         JOIN query_movies qm ON q.query_id = qm.query_id
         JOIN movies m ON qm.movie_id = m.movie_id;

alter table user_query_history
    owner to postgres;

