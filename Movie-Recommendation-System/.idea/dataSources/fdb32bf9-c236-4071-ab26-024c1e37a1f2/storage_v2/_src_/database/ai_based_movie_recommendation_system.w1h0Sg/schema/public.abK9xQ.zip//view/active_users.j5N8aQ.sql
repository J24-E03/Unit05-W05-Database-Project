create view active_users(username, full_name, total_queries) as
SELECT u.username,
       ud.full_name,
       count(q.query_id) AS total_queries
FROM users u
         JOIN queries q ON u.user_id = q.user_id
         JOIN user_details ud ON u.user_id = ud.user_id
GROUP BY u.username, ud.full_name
ORDER BY (count(q.query_id)) DESC;

alter table active_users
    owner to postgres;

