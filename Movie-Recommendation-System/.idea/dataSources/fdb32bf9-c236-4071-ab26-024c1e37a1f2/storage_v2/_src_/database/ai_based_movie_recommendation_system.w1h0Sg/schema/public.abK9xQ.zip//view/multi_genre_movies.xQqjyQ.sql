create view multi_genre_movies(title, genre_count) as
SELECT m.title,
       count(mg.genre_id) AS genre_count
FROM movies m
         JOIN movie_genres mg ON m.movie_id = mg.movie_id
GROUP BY m.title
HAVING count(mg.genre_id) > 1;

alter table multi_genre_movies
    owner to postgres;

