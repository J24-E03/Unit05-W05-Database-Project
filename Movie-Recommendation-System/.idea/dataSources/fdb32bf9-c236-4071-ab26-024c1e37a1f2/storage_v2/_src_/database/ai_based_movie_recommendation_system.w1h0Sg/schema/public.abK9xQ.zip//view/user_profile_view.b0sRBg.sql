create view user_profile_view(username, type, full_name, date_of_birth, email) as
SELECT u.username,
       u.type,
       d.full_name,
       d.date_of_birth,
       d.email
FROM users u
         JOIN user_details d ON u.user_id = d.user_id;

alter table user_profile_view
    owner to postgres;

