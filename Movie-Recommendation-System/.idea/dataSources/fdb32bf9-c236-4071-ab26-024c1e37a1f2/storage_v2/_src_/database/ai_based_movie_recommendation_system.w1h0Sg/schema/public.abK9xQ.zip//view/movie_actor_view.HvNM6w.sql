create view movie_actor_view("Movie Title", "Actor Name") as
SELECT m.title AS "Movie Title",
       a.name  AS "Actor Name"
FROM movies m
         JOIN movie_actors ma ON m.movie_id = ma.movie_id
         JOIN actors a ON ma.actor_id = a.actor_id;

alter table movie_actor_view
    owner to postgres;

