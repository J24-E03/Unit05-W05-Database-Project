create function delete_old_queries() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM queries
    WHERE timestamp < NOW() - INTERVAL '6 months';
    RETURN NULL;
END;
$$;

alter function delete_old_queries() owner to postgres;

