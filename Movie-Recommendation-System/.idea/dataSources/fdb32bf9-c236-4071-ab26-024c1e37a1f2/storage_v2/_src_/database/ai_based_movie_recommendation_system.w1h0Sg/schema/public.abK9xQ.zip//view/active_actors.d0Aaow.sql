create view active_actors(name, movie_count) as
SELECT a.name,
       count(ma.movie_id) AS movie_count
FROM actors a
         JOIN movie_actors ma ON a.actor_id = ma.actor_id
GROUP BY a.name
HAVING count(ma.movie_id) > 1;

alter table active_actors
    owner to postgres;

